package com.sunbeam.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class TagDto {
	
	private String name;
}
