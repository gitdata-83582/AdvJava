package com.sunbeam.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter

public class AddTagWithPostDto {
	
	private String Tagname;
	private String postTitle;
}
