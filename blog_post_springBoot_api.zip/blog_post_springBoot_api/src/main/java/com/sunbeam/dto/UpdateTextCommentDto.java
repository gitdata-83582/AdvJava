package com.sunbeam.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UpdateTextCommentDto {
private Long id;
private String text;
}
